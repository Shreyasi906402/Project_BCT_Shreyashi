# write a python program to take two sets and result union, intersction, difference, superset and subset.

set1 = {1,2,3,4,5}
set2 = {4,5,6,7,8}

def union_of_sets(set1, set2):
    return set1.union(set2)

def intersection_of_sets(set1, set2):
    return set1.intersection(set2)

def difference_of_sets(set1, set2):
    return set1.difference(set2)

def is_superset(set1, set2):
    return set1.issuperset(set2)

def is_subset(set1, set2):
    return set1.issubset(set2)

print(union_of_sets(set1, set2))
print(intersection_of_sets(set1, set2))
print(difference_of_sets(set1, set2))
print(is_subset(set1, set2))
print(is_subset(set1, set2))