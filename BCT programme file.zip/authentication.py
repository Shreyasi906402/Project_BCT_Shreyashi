from prettytable import PrettyTable

class AuthenticationSystem:
    def __init__(self):
        self.users = {}  # Dictionary to store users and their passwords

    def register(self, username, password):
        if username in self.users:
            raise ValueError("Username already exists.")
        self.users[username] = password
        print(f"User '{username}' registered successfully.")

    def sign_in(self, username, password):
        if username not in self.users:
            raise ValueError("Username not found.")
        if self.users[username] != password:
            raise ValueError("Incorrect password.")
        print(f"User '{username}' signed in successfully.")
        return True

    def search_user(self, username):
        if username in self.users:
            print(f"User '{username}' found. Password: {self.users[username]}")
        else:
            print("User not found.")

    def display_users(self):
        table = PrettyTable(["Username", "Password"])
        for username, password in self.users.items():
            table.add_row([username, password])
        print(table)

def display_menu():
    print("\n1. Register\n2. Sign In\n3. Search User\n4. Display Users\n5. Exit")

def main():
    auth_system = AuthenticationSystem()

    while True:
        display_menu()
        choice = input("Enter your choice: ")

        if choice == '1':
            username = input("Enter username: ")
            password = input("Enter password: ")
            try:
                auth_system.register(username, password)
            except ValueError as e:
                print(e)

        elif choice == '2':
            username = input("Enter username: ")
            password = input("Enter password: ")
            try:
                auth_system.sign_in(username, password)
            except ValueError as e:
                print(e)

        elif choice == '3':
            username = input("Enter username to search: ")
            auth_system.search_user(username)

        elif choice == '4':
            auth_system.display_users()

        elif choice == '5':
            print("Exiting the system. Goodbye!")
            break

        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
