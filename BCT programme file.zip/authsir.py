class AuthenticationSystem:
    def __init__(self):
        self.users = {}  # Dictionary to store users and their passwords

    def register(self, username, password):
        if username in self.users:
            raise ValueError(f"Username '{username}' already exists.")
        self.users[username] = password
        print(f"User '{username}' registered successfully.")

    def sign_in(self, username, password):
        if username not in self.users:
            raise ValueError(f"Username '{username}' not found.")
        if self.users[username] != password:
            raise ValueError("Incorrect password.")
        print(f"User '{username}' signed in successfully.")
        return True

# Example usage
auth_system = AuthenticationSystem()

# Register users
try:
    auth_system.register("alice", "password123")
    auth_system.register("bob", "mypassword")
except ValueError as e:
    print(e)

# Attempt to sign in
try:
    auth_system.sign_in("alice", "password123")  # Successful sign-in
    auth_system.sign_in("bob", "wrongpassword")  # Incorrect password
except ValueError as e:
    print(e)

# Try registering an existing user
try:
    auth_system.register("alice", "newpassword")
except ValueError as e:
    print(e)

# Try signing in with a non-existent user
try:
    auth_system.sign_in("charlie", "password123")
except ValueError as e:
    print(e)
