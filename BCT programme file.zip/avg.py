def avg(*n):
    s = 0
    for x in n:
        s = s + x
    return s/len(n)
x = avg(10,52,30,60)
print(f"the average is ",x)