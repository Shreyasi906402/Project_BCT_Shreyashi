class Test:
    i = 10
    def _init_(self):
        print("test")
        
    def f1(self):
       print("hello")
       
t1 = Test()
t1.f1()
