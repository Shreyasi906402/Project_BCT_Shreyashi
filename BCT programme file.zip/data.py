import requests
import json

pincode = input("Enter the pincode: ")
response = requests.get(f"https://api.postalpincode.in/pincode/{pincode}")


data = response.json()
post_office_info = data[0]['PostOffice']
print(post_office_info)