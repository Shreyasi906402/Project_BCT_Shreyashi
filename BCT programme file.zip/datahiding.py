class Test:
    x = 0
    __h = 20
    
print(Test.x)
print(Test.__h)