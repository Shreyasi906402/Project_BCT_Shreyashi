def armstrong(num):
    digits = str(num)
    power = len(digits)
    return num == sum(int(digit) ** power for digit in digits)

def armstronginrange(start, end):
    return [num for num in range(start, end + 1) if armstrong(num)]

start = int(input("Enter the first range: "))
end = int(input("Enter the second range: "))
    
print(armstronginrange(start, end))