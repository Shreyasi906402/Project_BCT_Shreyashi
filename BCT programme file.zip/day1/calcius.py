print("Enter the option given below")
print("1) Celcius to farenheit")
print("2) Farenheit to Celcius")

ch = int(input("Enter the option:"))

if(ch == 1):
    celsius = float(input("Enter the temperature in Celsius: "))
    farenheit = (celsius * 9/5) + 32
    print("Temperature in Fahrenheit is: ", farenheit)
elif(ch==2):
    farenheit = float(input("Enter the temperature in Fahrenheit: "))
    celsius = (farenheit - 32) * 5/9
    print("Temperature in Celsius is: ", celsius)