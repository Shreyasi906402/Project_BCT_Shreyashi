import math


def krishna(num):
    return num == sum(math.factorial(int(digit)) for digit in str(num))

def krishnainrange(start, end):
    return [num for num in range(start, end+1) if krishna(num)]

start = int(input("Enter the first range: "))
end = int(input("Enter the second range: "))
    
print(krishnainrange(start, end))