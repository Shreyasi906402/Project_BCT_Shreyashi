rg1 = int(input("Enter the first range: "))
rg2 = int(input("Enter the second range: "))

palindromenos = []
count = 0

for i in range(rg1, rg2+1, 1):
    num = str(i)
    if(num == num[::-1]):
        count = count + 1
        palindromenos.append(num)

print("Palindrome Numbers are: ", palindromenos)
print("Total palindromes: ", count)
