def print_stars(n):
    for i in range(n):
        left_stars = '*' * (i+1)
        spaces = ' ' * (2*(n-1-i))
        right_stars = '*' * (i+1)

        print(left_stars + spaces + right_stars)
        
n = int(input("Enter the number of rows: "))
print_stars(n)