rg1 = int(input("Enter the first range: "))
rg2 = int(input("Enter the second range: "))
list_odd = []
list_even = []
even_sum = 0
odd_sum = 0

for i in range(rg1,rg2+1, 1):
    if(i%2==0):
        list_even.append(i)
        even_sum += i
    else:
        list_odd.append(i)
        odd_sum += i

print("Odd number of list: ")
print(list_odd)
print("Sum of odd: ", odd_sum)

print("Even number of list: ")
print(list_even)
print("Sum of even: ", even_sum)
