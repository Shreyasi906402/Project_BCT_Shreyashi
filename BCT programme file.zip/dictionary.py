def display_menu():
    print("\nMenu:")
    print("1. Add New Entry")
    print("2. Delete Entry")
    print("3. Display Entries")
    print("4. Exit")

def add_entry(phonebook):
    name = input("Enter name: ")
    status = True
    while status:
        phone = input("Enter phone number (10 digits): ")

        if not phone.isdigit() or len(phone) != 10 or phone.startswith('5') or phone.startswith('4') or phone.startswith('3') or phone.startswith('2') or phone.startswith('1') or phone.startswith('0'):
            print("Invalid Indian phone number:", phone)
            print("PLease Try again!")
        else:
            status = False

    phone = int(phone)

    address = input("Enter address: ")
    phonebook[name] = {'Phone': phone, 'Address': address}
    print(f"Entry added for {name}")


def delete_entry(phonebook):
    name = input("Enter the name of the entry to delete: ")
    if name in phonebook:
        del phonebook[name]
        print(f"Entry for {name} deleted")
    else:
        print(f"No entry found for {name}")

def display_entries(phonebook):
    if phonebook:
        for name, details in phonebook.items():
            print(f"Name: {name}")
            print(f"Phone: {details['Phone']}")
            print(f"Address: {details['Address']}")
            print("-" * 20)
    else:
        print("Phonebook is empty. There is nothing to show!")

def main():
    phonebook = {}
    while True:
        display_menu()
        choice = input("Enter your choice: ")
        if choice == '1':
            add_entry(phonebook)
        elif choice == '2':
            delete_entry(phonebook)
        elif choice == '3':
            display_entries(phonebook)
        elif choice == '4':
            print("Exiting the software!")
            break
        else:
            print("Invalid choice")

if __name__ == "__main__":
    main()