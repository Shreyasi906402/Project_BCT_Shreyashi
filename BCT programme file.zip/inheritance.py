class Person:
    def __init__(self, n, a):
        self.name = n
        self.age = a

    def showName(self):
        print("Name =", self.name)

    def showAge(self):
        print("Age =", self.age)

class Student(Person):
    def __init__(self, n, a, r):
        super().__init__(n, a)
        self.rollno = r

    def showRollno(self):
        print("Roll number", self.rollno)

# Getting user input
name = input("Enter student's name: ")
age = int(input("Enter student's age: "))
roll_number = int(input("Enter student's roll number: "))

# Creating an instance of Student with user input
s1 = Student(name, age, roll_number)

# Accessing methods of the parent class
s1.showName()
s1.showAge()

# Accessing method of the child class
s1.showRollno()
