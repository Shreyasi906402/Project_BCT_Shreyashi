lines = 5
for i in range(1, lines+1):
    print("*" * i)