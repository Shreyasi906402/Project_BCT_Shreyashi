pattern = [
    "*   *\n"
    "** **\n"
    "*****\n"
]
for line in pattern:
    print(line)
