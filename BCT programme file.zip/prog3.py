a = int(input("Enter the first number: "))
b = int(input("Enter the second number: "))

print("Enter the option to calculate: ")
print("1. Addition")
print("2. Substraction")
print("3. Division")
print("4. Multiplication")
print("5. Modulus(Remainder)")
ch = int(input("Enter your choice: "))

if(ch==1):
   print(a+b)
elif(ch==2):
   print(a-b)
elif(ch==3):
   print(a/b)
elif(ch==4):
   print(a*b)
elif(ch==5):
   print(a%b)
