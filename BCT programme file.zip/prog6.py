#Find the range palindrome
rag1 = int(input("Enter the first number: "))
rag2 = int(input("Enter the second number: "))

palindromenos = []
count = 0

for i in range(rag1, rag2+1, 1):
    num = str(i)
    if(num == num[::-1]):
        count = count+1
        palindromenos.append(num)
        
print("Palindrome numbers are: ", palindromenos)
print("total palindrome: ",count)