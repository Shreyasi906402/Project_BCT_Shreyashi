p = int(input("Enter the value of p: "))
r = int(input("Enter the value of r: "))
t = int(input("Enter the value of t: "))
result = (p*r*t)/100
print(result)