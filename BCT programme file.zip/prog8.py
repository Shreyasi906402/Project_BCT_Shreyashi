print("Enter the option given below: ")
print("1)Calculate in Farenheit scale to Celcius scale: ")
print("2)Calculate in Celcius to scale to Farenheit scale: ")

ch = int(input("Enter the option: "))

if(ch == 1):
    celcius = float(input("Enter the temperature in celcius: "))
    farenheit = (celcius *9/5) + 32
    print("Temperature in farenheit is: ", farenheit)
    
elif(ch == 2):
      farenheit = float(input("Enter the temperature in farenheit: "))
      celcius = (farenheit - 32) *5/9
      print("Temperature in celcius is: ", celcius)

