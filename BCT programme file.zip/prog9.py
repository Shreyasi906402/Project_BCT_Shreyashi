num1 = int(input("Enter the first number: "))
num2 = int(input("Enter the second number: "))

def divide_numbers(num1, num2):
    try:
        result = num1/ num2
        return result
    
    except ValueError as e:
        return f"Error: {e}"
    except ZeroDivisionError as e:
        return f"Error: {e}"
    except TypeError as e:
        return f"Error: {e}"
    
    print(divide_numbers(num1, num2))
        
    