def process_numbers():
    num_count = int(input("How many numbers do you want to enter? "))

    numbers_tuple = ()

    for _ in range(num_count):
        number = int(input("Enter a number: "))
        numbers_tuple += (number,)

    numbers_list = list(numbers_tuple)

    append_number = int(input("Enter a number to append to the list: "))
    numbers_list.append(append_number)


    print("Original tuple:", numbers_tuple)
    print("Converted tuple:", tuple(numbers_list))

process_numbers()